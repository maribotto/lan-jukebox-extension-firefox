// Content script for YouTube pages
// This script runs on all YouTube pages and can be used for future enhancements
// like adding a "Add to Jukebox" button directly on the YouTube page

// Currently, this is a placeholder for future functionality
// The main functionality is in the popup

console.log('LAN Jukebox extension loaded on YouTube page');

// You could add functionality here like:
// - Adding a button to the YouTube player controls
// - Keyboard shortcuts to add videos
// - Auto-detection of playlist URLs
// etc.
